import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.toyshop.manager',
  appName: 'Toy Shop Manager',
  webDir: 'dist',
  bundledWebRuntime: false,
  android: {
    backgroundColor: '#f9fafb',
  },
};

export default config;
