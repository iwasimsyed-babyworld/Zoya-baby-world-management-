/*
# Toy & Cycle Shop Inventory Management Schema

1. Overview
This creates the complete database schema for a single-tenant toy & cycle shop inventory
management application. No authentication is required — the app operates as a single shop
with shared data accessible via the anon key.

2. New Tables
- `products`: Inventory items (toys, cycles, etc.) with pricing, stock, and supplier info.
  - id (uuid, primary key)
  - code (text, unique product code like TOY0001)
  - name (text, product name)
  - category (text, product category)
  - purchase_price (numeric, base purchase cost)
  - transport_cost (numeric, transport cost per unit)
  - fitting_cost (numeric, fitting/assembly cost per unit)
  - landed_cost (numeric, total landed cost = purchase + transport + fitting)
  - selling_price (numeric, retail selling price)
  - stock (integer, current quantity in stock)
  - low_stock (integer, threshold for low stock alerts)
  - supplier (text, supplier name)
  - notes (text, additional notes)
  - date_added (date, when product was added)
  - created_at (timestamptz)

- `sales`: Sales transactions.
  - id (uuid, primary key)
  - product_id (uuid, FK to products)
  - product_name (text, snapshot of product name at time of sale)
  - qty (integer, quantity sold)
  - unit_price (numeric, selling price per unit)
  - discount (numeric, discount amount)
  - final_amount (numeric, total after discount)
  - gross_profit (numeric, profit = final_amount - (landed_cost * qty))
  - customer_name (text, optional)
  - payment_mode (text, cash/card/upi/etc)
  - date (date, sale date)
  - created_at (timestamptz)

- `purchases`: Purchase/restock transactions.
  - id (uuid, primary key)
  - product_id (uuid, FK to products)
  - product_name (text, snapshot of product name)
  - qty (integer, quantity purchased)
  - purchase_price (numeric, unit purchase price)
  - transport_cost (numeric, total transport cost)
  - fitting_cost (numeric, total fitting cost)
  - total_landed (numeric, total landed cost for this purchase)
  - supplier (text, supplier name)
  - date (date, purchase date)
  - created_at (timestamptz)

- `expenses`: Shop expenses (rent, electricity, etc.).
  - id (uuid, primary key)
  - category (text, expense category)
  - description (text, expense description)
  - amount (numeric, expense amount)
  - date (date, expense date)
  - created_at (timestamptz)

- `settings`: Shop configuration (single row).
  - id (integer, primary key, always 1)
  - shop_name (text)
  - shop_address (text)
  - phone (text)
  - gst (text, GST number)
  - allow_negative_stock (boolean)
  - low_stock_default (integer)
  - updated_at (timestamptz)

3. Security
- RLS enabled on all tables.
- All tables use `TO anon, authenticated` policies since this is a single-tenant app
  with no sign-in screen. Data is intentionally shared/public within the shop.

4. Notes
- Settings table holds a single row (id=1) for shop configuration.
- Sales and purchases store product_name as a snapshot for historical records.
- Landed cost is calculated as purchase_price + transport_cost + fitting_cost.
*/

-- Products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  name text NOT NULL,
  category text NOT NULL DEFAULT 'General',
  purchase_price numeric NOT NULL DEFAULT 0,
  transport_cost numeric NOT NULL DEFAULT 0,
  fitting_cost numeric NOT NULL DEFAULT 0,
  landed_cost numeric NOT NULL DEFAULT 0,
  selling_price numeric NOT NULL DEFAULT 0,
  stock integer NOT NULL DEFAULT 0,
  low_stock integer NOT NULL DEFAULT 2,
  supplier text DEFAULT '',
  notes text DEFAULT '',
  date_added date DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_products" ON products;
CREATE POLICY "anon_select_products" ON products FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_products" ON products;
CREATE POLICY "anon_insert_products" ON products FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_products" ON products;
CREATE POLICY "anon_update_products" ON products FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_products" ON products;
CREATE POLICY "anon_delete_products" ON products FOR DELETE
  TO anon, authenticated USING (true);

-- Sales table
CREATE TABLE IF NOT EXISTS sales (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES products(id) ON DELETE SET NULL,
  product_name text NOT NULL,
  qty integer NOT NULL,
  unit_price numeric NOT NULL DEFAULT 0,
  discount numeric NOT NULL DEFAULT 0,
  final_amount numeric NOT NULL DEFAULT 0,
  gross_profit numeric NOT NULL DEFAULT 0,
  customer_name text DEFAULT '',
  payment_mode text DEFAULT 'Cash',
  date date DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE sales ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_sales" ON sales;
CREATE POLICY "anon_select_sales" ON sales FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_sales" ON sales;
CREATE POLICY "anon_insert_sales" ON sales FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_sales" ON sales;
CREATE POLICY "anon_update_sales" ON sales FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_sales" ON sales;
CREATE POLICY "anon_delete_sales" ON sales FOR DELETE
  TO anon, authenticated USING (true);

-- Purchases table
CREATE TABLE IF NOT EXISTS purchases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES products(id) ON DELETE SET NULL,
  product_name text NOT NULL,
  qty integer NOT NULL,
  purchase_price numeric NOT NULL DEFAULT 0,
  transport_cost numeric NOT NULL DEFAULT 0,
  fitting_cost numeric NOT NULL DEFAULT 0,
  total_landed numeric NOT NULL DEFAULT 0,
  supplier text DEFAULT '',
  date date DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE purchases ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_purchases" ON purchases;
CREATE POLICY "anon_select_purchases" ON purchases FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_purchases" ON purchases;
CREATE POLICY "anon_insert_purchases" ON purchases FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_purchases" ON purchases;
CREATE POLICY "anon_update_purchases" ON purchases FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_purchases" ON purchases;
CREATE POLICY "anon_delete_purchases" ON purchases FOR DELETE
  TO anon, authenticated USING (true);

-- Expenses table
CREATE TABLE IF NOT EXISTS expenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category text NOT NULL,
  description text DEFAULT '',
  amount numeric NOT NULL DEFAULT 0,
  date date DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE expenses ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_expenses" ON expenses;
CREATE POLICY "anon_select_expenses" ON expenses FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_expenses" ON expenses;
CREATE POLICY "anon_insert_expenses" ON expenses FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_expenses" ON expenses;
CREATE POLICY "anon_update_expenses" ON expenses FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_expenses" ON expenses;
CREATE POLICY "anon_delete_expenses" ON expenses FOR DELETE
  TO anon, authenticated USING (true);

-- Settings table (single-row)
CREATE TABLE IF NOT EXISTS settings (
  id integer PRIMARY KEY DEFAULT 1,
  shop_name text NOT NULL DEFAULT 'My Toy & Cycle Shop',
  shop_address text DEFAULT 'Main Bazaar, India',
  phone text DEFAULT '9876543210',
  gst text DEFAULT '',
  allow_negative_stock boolean NOT NULL DEFAULT false,
  low_stock_default integer NOT NULL DEFAULT 2,
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT single_row CHECK (id = 1)
);

ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_settings" ON settings;
CREATE POLICY "anon_select_settings" ON settings FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_settings" ON settings;
CREATE POLICY "anon_insert_settings" ON settings FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_settings" ON settings;
CREATE POLICY "anon_update_settings" ON settings FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_settings" ON settings;
CREATE POLICY "anon_delete_settings" ON settings FOR DELETE
  TO anon, authenticated USING (true);

-- Insert default settings row if not exists
INSERT INTO settings (id, shop_name, shop_address, phone, gst, allow_negative_stock, low_stock_default)
SELECT 1, 'My Toy & Cycle Shop', 'Main Bazaar, India', '9876543210', '', false, 2
WHERE NOT EXISTS (SELECT 1 FROM settings WHERE id = 1);

-- Seed sample products
INSERT INTO products (code, name, category, purchase_price, transport_cost, fitting_cost, landed_cost, selling_price, stock, low_stock, supplier, notes)
SELECT 'TOY0001', 'Battery Car Big Wheels', 'Battery Cars', 4800, 0, 0, 4800, 7000, 5, 2, 'ToyWala Corp', 'Popular item'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE code = 'TOY0001');

INSERT INTO products (code, name, category, purchase_price, transport_cost, fitting_cost, landed_cost, selling_price, stock, low_stock, supplier, notes)
SELECT 'CYC0001', 'Hero Ranger Cycle 26T', 'Cycles', 5000, 300, 200, 5500, 6500, 3, 2, 'Hero Cycles Ltd', 'Includes assembled kit'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE code = 'CYC0001');

-- Seed sample purchases
INSERT INTO purchases (product_id, product_name, qty, purchase_price, transport_cost, fitting_cost, total_landed, supplier, date)
SELECT (SELECT id FROM products WHERE code = 'TOY0001'), 'Battery Car Big Wheels', 5, 4800, 0, 0, 24000, 'ToyWala Corp', CURRENT_DATE
WHERE NOT EXISTS (SELECT 1 FROM purchases LIMIT 1);

INSERT INTO purchases (product_id, product_name, qty, purchase_price, transport_cost, fitting_cost, total_landed, supplier, date)
SELECT (SELECT id FROM products WHERE code = 'CYC0001'), 'Hero Ranger Cycle 26T', 3, 5000, 300, 200, 16500, 'Hero Cycles Ltd', CURRENT_DATE
WHERE NOT EXISTS (SELECT 1 FROM purchases WHERE product_name = 'Hero Ranger Cycle 26T');

-- Add indexes for frequently queried columns
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
CREATE INDEX IF NOT EXISTS idx_products_code ON products(code);
CREATE INDEX IF NOT EXISTS idx_sales_date ON sales(date);
CREATE INDEX IF NOT EXISTS idx_purchases_date ON purchases(date);
CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(date);
