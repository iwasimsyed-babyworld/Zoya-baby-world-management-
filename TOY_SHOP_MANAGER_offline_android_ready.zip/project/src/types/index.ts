export interface Product {
  id: string;
  code: string;
  name: string;
  category: string;
  purchase_price: number;
  transport_cost: number;
  fitting_cost: number;
  landed_cost: number;
  selling_price: number;
  stock: number;
  low_stock: number;
  supplier: string;
  notes: string;
  date_added: string;
  created_at: string;
}

export interface Sale {
  id: string;
  product_id: string | null;
  product_name: string;
  qty: number;
  unit_price: number;
  discount: number;
  final_amount: number;
  gross_profit: number;
  customer_name: string;
  payment_mode: string;
  date: string;
  created_at: string;
}

export interface Purchase {
  id: string;
  product_id: string | null;
  product_name: string;
  qty: number;
  purchase_price: number;
  transport_cost: number;
  fitting_cost: number;
  total_landed: number;
  supplier: string;
  date: string;
  created_at: string;
}

export interface Expense {
  id: string;
  category: string;
  description: string;
  amount: number;
  date: string;
  created_at: string;
}

export interface ShopSettings {
  id: number;
  shop_name: string;
  shop_address: string;
  phone: string;
  gst: string;
  allow_negative_stock: boolean;
  low_stock_default: number;
  updated_at: string;
}

export type TabId = 'dashboard' | 'products' | 'sales' | 'stock' | 'expenses' | 'reports' | 'settings';
