import { useState } from 'react';
import { FileText, TrendingUp, TrendingDown, DollarSign, ShoppingCart, Package, Download } from 'lucide-react';
import type { Product, Sale, Purchase, Expense } from '@/types';

interface ReportsViewProps {
  sales: Sale[];
  expenses: Expense[];
  products: Product[];
  purchases: Purchase[];
}

function formatCurrency(n: number): string {
  return '₹' + n.toLocaleString('en-IN');
}

type Period = 'today' | 'week' | 'month' | 'all';

export default function ReportsView({ sales, expenses, products, purchases }: ReportsViewProps) {
  const [period, setPeriod] = useState<Period>('month');

  const getPeriodStart = (p: Period): string => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    switch (p) {
      case 'today':
        return today.toISOString().split('T')[0];
      case 'week': {
        const weekAgo = new Date(today);
        weekAgo.setDate(weekAgo.getDate() - 7);
        return weekAgo.toISOString().split('T')[0];
      }
      case 'month':
        return now.toISOString().substring(0, 7);
      case 'all':
        return '0000-01-01';
    }
  };

  const periodStart = getPeriodStart(period);

  const periodSales = sales.filter((s) => s.date >= periodStart);
  const periodExpenses = expenses.filter((e) => e.date >= periodStart);
  const periodPurchases = purchases.filter((p) => p.date >= periodStart);

  const totalRevenue = periodSales.reduce((acc, s) => acc + s.final_amount, 0);
  const totalGrossProfit = periodSales.reduce((acc, s) => acc + s.gross_profit, 0);
  const totalExpenses = periodExpenses.reduce((acc, e) => acc + e.amount, 0);
  const totalPurchaseCost = periodPurchases.reduce((acc, p) => acc + p.total_landed, 0);
  const netProfit = totalGrossProfit - totalExpenses;
  const totalUnitsSold = periodSales.reduce((acc, s) => acc + s.qty, 0);
  const totalUnitsPurchased = periodPurchases.reduce((acc, p) => acc + p.qty, 0);
  const stockValue = products.reduce((acc, p) => acc + p.stock * p.landed_cost, 0);

  // Top selling products
  const productSalesMap = new Map<string, { name: string; qty: number; revenue: number; profit: number }>();
  periodSales.forEach((s) => {
    const existing = productSalesMap.get(s.product_name) || { name: s.product_name, qty: 0, revenue: 0, profit: 0 };
    existing.qty += s.qty;
    existing.revenue += s.final_amount;
    existing.profit += s.gross_profit;
    productSalesMap.set(s.product_name, existing);
  });
  const topProducts = Array.from(productSalesMap.values()).sort((a, b) => b.revenue - a.revenue).slice(0, 5);

  // Expense breakdown
  const expenseMap = new Map<string, number>();
  periodExpenses.forEach((e) => {
    expenseMap.set(e.category, (expenseMap.get(e.category) || 0) + e.amount);
  });
  const expenseBreakdown = Array.from(expenseMap.entries()).sort((a, b) => b[1] - a[1]);

  const handleExport = () => {
    const lines: string[] = [];
    lines.push(`Shop Report - ${period.toUpperCase()}`);
    lines.push(`Generated: ${new Date().toLocaleString()}`);
    lines.push('');
    lines.push('=== SUMMARY ===');
    lines.push(`Total Revenue: ${formatCurrency(totalRevenue)}`);
    lines.push(`Gross Profit: ${formatCurrency(totalGrossProfit)}`);
    lines.push(`Total Expenses: ${formatCurrency(totalExpenses)}`);
    lines.push(`Net Profit: ${formatCurrency(netProfit)}`);
    lines.push(`Units Sold: ${totalUnitsSold}`);
    lines.push(`Units Purchased: ${totalUnitsPurchased}`);
    lines.push(`Purchase Cost: ${formatCurrency(totalPurchaseCost)}`);
    lines.push(`Current Stock Value: ${formatCurrency(stockValue)}`);
    lines.push('');
    lines.push('=== TOP PRODUCTS ===');
    topProducts.forEach((p, i) => {
      lines.push(`${i + 1}. ${p.name} - ${p.qty} units, Revenue: ${formatCurrency(p.revenue)}, Profit: ${formatCurrency(p.profit)}`);
    });
    lines.push('');
    lines.push('=== EXPENSE BREAKDOWN ===');
    expenseBreakdown.forEach(([cat, amt]) => {
      lines.push(`${cat}: ${formatCurrency(amt)}`);
    });

    const blob = new Blob([lines.join('\n')], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `shop-report-${period}-${new Date().toISOString().split('T')[0]}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const PERIODS: { id: Period; label: string }[] = [
    { id: 'today', label: 'Today' },
    { id: 'week', label: 'Week' },
    { id: 'month', label: 'Month' },
    { id: 'all', label: 'All Time' },
  ];

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-gray-800">Reports</h2>
        <button
          onClick={handleExport}
          className="bg-slate-800 text-white px-4 py-2 rounded-xl text-sm font-semibold flex items-center gap-1.5 shadow-sm hover:bg-slate-900 transition-colors"
        >
          <Download size={16} />
          <span>Export</span>
        </button>
      </div>

      {/* Period Selector */}
      <div className="grid grid-cols-4 gap-2">
        {PERIODS.map((p) => (
          <button
            key={p.id}
            onClick={() => setPeriod(p.id)}
            className={`py-2 rounded-xl text-xs font-semibold transition-colors ${
              period === p.id
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-white text-gray-500 border border-gray-200 hover:bg-gray-50'
            }`}
          >
            {p.label}
          </button>
        ))}
      </div>

      {/* P&L Summary */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 p-5 rounded-2xl shadow-md">
        <h3 className="text-sm font-semibold text-slate-300 mb-4">Profit & Loss</h3>
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-xs text-slate-400">Revenue</span>
            <span className="text-sm font-bold text-white">{formatCurrency(totalRevenue)}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-xs text-slate-400">Gross Profit</span>
            <span className="text-sm font-bold text-emerald-400">{formatCurrency(totalGrossProfit)}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-xs text-slate-400">Expenses</span>
            <span className="text-sm font-bold text-rose-400">-{formatCurrency(totalExpenses)}</span>
          </div>
          <div className="border-t border-slate-700 pt-3 flex justify-between items-center">
            <span className="text-sm font-semibold text-slate-300">Net Profit</span>
            <span className={`text-lg font-extrabold ${netProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>{formatCurrency(netProfit)}</span>
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
          <div className="flex items-center gap-2 text-gray-400">
            <ShoppingCart size={14} />
            <span className="text-xs font-medium">Units Sold</span>
          </div>
          <p className="text-xl font-bold text-gray-800 mt-1">{totalUnitsSold}</p>
        </div>
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
          <div className="flex items-center gap-2 text-gray-400">
            <Package size={14} />
            <span className="text-xs font-medium">Units Purchased</span>
          </div>
          <p className="text-xl font-bold text-gray-800 mt-1">{totalUnitsPurchased}</p>
        </div>
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
          <div className="flex items-center gap-2 text-gray-400">
            <DollarSign size={14} />
            <span className="text-xs font-medium">Purchase Cost</span>
          </div>
          <p className="text-xl font-bold text-blue-600 mt-1">{formatCurrency(totalPurchaseCost)}</p>
        </div>
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
          <div className="flex items-center gap-2 text-gray-400">
            <TrendingUp size={14} />
            <span className="text-xs font-medium">Stock Value</span>
          </div>
          <p className="text-xl font-bold text-gray-800 mt-1">{formatCurrency(stockValue)}</p>
        </div>
      </div>

      {/* Top Products */}
      <div>
        <h3 className="text-sm font-semibold text-gray-600 mb-2 px-1">Top Products</h3>
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
          {topProducts.length === 0 ? (
            <p className="text-sm text-gray-400 text-center py-4">No sales in this period</p>
          ) : (
            <div className="space-y-3">
              {topProducts.map((p, i) => (
                <div key={i} className="flex justify-between items-center pb-3 border-b border-gray-50 last:border-0 last:pb-0">
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-bold text-gray-400 w-5">{i + 1}</span>
                    <div>
                      <p className="text-sm font-semibold text-gray-800">{p.name}</p>
                      <p className="text-[10px] text-gray-400">{p.qty} units sold</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-blue-600">{formatCurrency(p.revenue)}</p>
                    <p className="text-[10px] text-emerald-600">+{formatCurrency(p.profit)}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Expense Breakdown */}
      {expenseBreakdown.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold text-gray-600 mb-2 px-1">Expense Breakdown</h3>
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 space-y-3">
            {expenseBreakdown.map(([cat, amt]) => {
              const pct = totalExpenses > 0 ? (amt / totalExpenses) * 100 : 0;
              return (
                <div key={cat}>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium text-gray-700">{cat}</span>
                    <span className="text-sm font-bold text-rose-600">{formatCurrency(amt)}</span>
                  </div>
                  <div className="w-full bg-gray-100 rounded-full h-1.5">
                    <div className="bg-rose-500 h-1.5 rounded-full transition-all" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
