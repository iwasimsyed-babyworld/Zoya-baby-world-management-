import { AlertTriangle, TrendingUp, TrendingDown, Package, DollarSign, ShoppingCart, Wallet } from 'lucide-react';
import type { Product, Sale } from '@/types';

interface DashboardViewProps {
  todayRevenue: number;
  todayGrossProfit: number;
  todayExpenseTotal: number;
  todayNetProfit: number;
  monthRevenue: number;
  monthGrossProfit: number;
  monthExpenseTotal: number;
  monthNetProfit: number;
  totalStockValue: number;
  totalUnitsInStock: number;
  lowStockItems: Product[];
  recentSales: Sale[];
}

function formatCurrency(n: number): string {
  return '₹' + n.toLocaleString('en-IN');
}

export default function DashboardView({
  todayRevenue, todayGrossProfit, todayExpenseTotal, todayNetProfit,
  monthRevenue, monthGrossProfit, monthExpenseTotal, monthNetProfit,
  totalStockValue, totalUnitsInStock, lowStockItems, recentSales
}: DashboardViewProps) {
  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl font-bold text-gray-800">Shop Overview</h2>
        <p className="text-sm text-gray-500 mt-0.5">Real-time snapshot of your business</p>
      </div>

      {/* Today's Performance */}
      <div>
        <h3 className="text-sm font-semibold text-gray-600 mb-2 px-1">Today</h3>
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-gradient-to-br from-blue-500 to-blue-600 p-4 rounded-2xl shadow-sm">
            <div className="flex items-center gap-2 text-blue-100">
              <ShoppingCart size={16} />
              <span className="text-xs font-medium">Sales</span>
            </div>
            <p className="text-2xl font-extrabold text-white mt-2">{formatCurrency(todayRevenue)}</p>
          </div>
          <div className={`bg-gradient-to-br p-4 rounded-2xl shadow-sm ${todayNetProfit >= 0 ? 'from-emerald-500 to-emerald-600' : 'from-rose-500 to-rose-600'}`}>
            <div className="flex items-center gap-2 text-white/80">
              <Wallet size={16} />
              <span className="text-xs font-medium">Net Profit</span>
            </div>
            <p className="text-2xl font-extrabold text-white mt-2">{formatCurrency(todayNetProfit)}</p>
          </div>
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 text-gray-400">
              <TrendingUp size={16} />
              <span className="text-xs font-medium">Gross Profit</span>
            </div>
            <p className="text-xl font-bold text-blue-600 mt-2">{formatCurrency(todayGrossProfit)}</p>
          </div>
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 text-gray-400">
              <TrendingDown size={16} />
              <span className="text-xs font-medium">Expenses</span>
            </div>
            <p className="text-xl font-bold text-rose-500 mt-2">{formatCurrency(todayExpenseTotal)}</p>
          </div>
        </div>
      </div>

      {/* Monthly Summary */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 p-4 rounded-2xl shadow-md">
        <h3 className="text-sm font-semibold text-slate-300 mb-3">This Month</h3>
        <div className="grid grid-cols-3 gap-3">
          <div className="text-center">
            <p className="text-[10px] text-slate-400 uppercase tracking-wide">Revenue</p>
            <p className="text-base font-bold text-white mt-1">{formatCurrency(monthRevenue)}</p>
          </div>
          <div className="text-center border-x border-slate-700">
            <p className="text-[10px] text-slate-400 uppercase tracking-wide">Expenses</p>
            <p className="text-base font-bold text-rose-400 mt-1">{formatCurrency(monthExpenseTotal)}</p>
          </div>
          <div className="text-center">
            <p className="text-[10px] text-slate-400 uppercase tracking-wide">Net Profit</p>
            <p className={`text-base font-bold mt-1 ${monthNetProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>{formatCurrency(monthNetProfit)}</p>
          </div>
        </div>
      </div>

      {/* Stock Summary */}
      <div>
        <h3 className="text-sm font-semibold text-gray-600 mb-2 px-1">Inventory</h3>
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-white p-3 rounded-2xl shadow-sm border border-gray-100 text-center">
            <Package size={18} className="text-gray-400 mx-auto" />
            <p className="text-lg font-bold text-gray-800 mt-1">{totalUnitsInStock}</p>
            <p className="text-[10px] text-gray-500">Units in Stock</p>
          </div>
          <div className="bg-white p-3 rounded-2xl shadow-sm border border-gray-100 text-center">
            <DollarSign size={18} className="text-gray-400 mx-auto" />
            <p className="text-sm font-bold text-gray-800 mt-1">{formatCurrency(totalStockValue)}</p>
            <p className="text-[10px] text-gray-500">Stock Value</p>
          </div>
          <div className="bg-white p-3 rounded-2xl shadow-sm border border-gray-100 text-center">
            <AlertTriangle size={18} className="text-amber-500 mx-auto" />
            <p className="text-lg font-bold text-amber-600 mt-1">{lowStockItems.length}</p>
            <p className="text-[10px] text-gray-500">Low Stock Items</p>
          </div>
        </div>
      </div>

      {/* Low Stock Alert */}
      {lowStockItems.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 p-4 rounded-2xl">
          <div className="flex items-center gap-2 text-amber-800 font-semibold text-sm">
            <AlertTriangle size={16} />
            <span>Low Stock Warning</span>
          </div>
          <div className="mt-3 space-y-2">
            {lowStockItems.map((item) => (
              <div key={item.id} className="flex justify-between items-center bg-white px-3 py-2 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-gray-800">{item.name}</p>
                  <p className="text-[10px] text-gray-400">{item.code}</p>
                </div>
                <span className="text-xs font-bold text-amber-600 bg-amber-100 px-2 py-1 rounded-md">
                  {item.stock} left
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recent Sales */}
      <div>
        <h3 className="text-sm font-semibold text-gray-600 mb-2 px-1">Recent Sales</h3>
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
          {recentSales.length === 0 ? (
            <div className="text-center py-6">
              <ShoppingCart size={24} className="text-gray-300 mx-auto" />
              <p className="text-sm text-gray-400 mt-2">No sales recorded yet</p>
            </div>
          ) : (
            <div className="space-y-3">
              {recentSales.map((sale) => (
                <div key={sale.id} className="flex justify-between items-center pb-3 border-b border-gray-50 last:border-0 last:pb-0">
                  <div>
                    <p className="text-sm font-semibold text-gray-800">{sale.product_name}</p>
                    <p className="text-[10px] text-gray-400">{sale.date} · Qty: {sale.qty}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-blue-600">{formatCurrency(sale.final_amount)}</p>
                    <p className="text-[10px] text-emerald-600 font-medium">+{formatCurrency(sale.gross_profit)} profit</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
