import { useState } from 'react';
import { Plus, X, Trash2, DollarSign, Receipt } from 'lucide-react';
import type { Expense } from '@/types';
import { supabase } from '@/lib/supabase';

interface ExpensesViewProps {
  expenses: Expense[];
  onExpensesChange: () => void;
  showNotification: (msg: string) => void;
}

function formatCurrency(n: number): string {
  return '₹' + n.toLocaleString('en-IN');
}

const EXPENSE_CATEGORIES = ['Rent', 'Electricity', 'Salary', 'Transport', 'Maintenance', 'Marketing', 'Miscellaneous'];

export default function ExpensesView({ expenses, onExpensesChange, showNotification }: ExpensesViewProps) {
  const [showModal, setShowModal] = useState(false);
  const [saving, setSaving] = useState(false);

  const [category, setCategory] = useState('Rent');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');

  const openModal = () => {
    setCategory('Rent');
    setDescription('');
    setAmount('');
    setShowModal(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || Number(amount) <= 0) {
      showNotification('Please enter a valid amount');
      return;
    }

    setSaving(true);
    try {
      const { error } = await supabase.from('expenses').insert({
        category,
        description,
        amount: Number(amount),
        date: new Date().toISOString().split('T')[0],
      });
      if (error) throw error;

      showNotification('Expense recorded');
      setShowModal(false);
      onExpensesChange();
    } catch (err) {
      showNotification('Error saving expense');
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Delete this expense?')) return;
    try {
      const { error } = await supabase.from('expenses').delete().eq('id', id);
      if (error) throw error;
      showNotification('Expense deleted');
      onExpensesChange();
    } catch (err) {
      showNotification('Error deleting expense');
      console.error(err);
    }
  };

  // Today and month totals
  const todayStr = new Date().toISOString().split('T')[0];
  const monthStr = todayStr.substring(0, 7);
  const todayTotal = expenses.filter((e) => e.date === todayStr).reduce((acc, e) => acc + e.amount, 0);
  const monthTotal = expenses.filter((e) => e.date.startsWith(monthStr)).reduce((acc, e) => acc + e.amount, 0);

  const sortedExpenses = [...expenses].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-gray-800">Expenses</h2>
        <button
          onClick={openModal}
          className="bg-rose-600 text-white px-4 py-2 rounded-xl text-sm font-semibold flex items-center gap-1.5 shadow-sm hover:bg-rose-700 transition-colors"
        >
          <Plus size={18} />
          <span>Add</span>
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
          <p className="text-xs text-gray-500 font-medium">Today's Expenses</p>
          <p className="text-xl font-extrabold text-rose-600 mt-1">{formatCurrency(todayTotal)}</p>
        </div>
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
          <p className="text-xs text-gray-500 font-medium">This Month</p>
          <p className="text-xl font-extrabold text-rose-500 mt-1">{formatCurrency(monthTotal)}</p>
        </div>
      </div>

      {/* Expense List */}
      {sortedExpenses.length === 0 ? (
        <div className="text-center py-12">
          <Receipt size={32} className="text-gray-300 mx-auto" />
          <p className="text-sm text-gray-400 mt-2">No expenses recorded yet</p>
        </div>
      ) : (
        <div className="space-y-3">
          {sortedExpenses.map((exp) => (
            <div key={exp.id} className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-medium text-rose-600 bg-rose-50 px-2 py-0.5 rounded-md">{exp.category}</span>
                  </div>
                  {exp.description && (
                    <p className="text-sm text-gray-700 mt-1.5">{exp.description}</p>
                  )}
                  <p className="text-[10px] text-gray-400 mt-1">{exp.date}</p>
                </div>
                <div className="flex items-center gap-2">
                  <p className="text-sm font-bold text-rose-600">{formatCurrency(exp.amount)}</p>
                  <button
                    onClick={() => handleDelete(exp.id)}
                    className="p-1.5 text-gray-300 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Expense Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-end sm:items-center justify-center z-50 p-0 sm:p-4">
          <div className="bg-white w-full sm:max-w-md rounded-t-3xl sm:rounded-3xl">
            <div className="flex justify-between items-center p-4 border-b border-gray-100">
              <h3 className="text-lg font-bold text-gray-800">Add Expense</h3>
              <button onClick={() => setShowModal(false)} className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg">
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleSave} className="p-4 space-y-4">
              <div>
                <label className="text-xs font-semibold text-gray-600 mb-1 block">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-rose-500"
                >
                  {EXPENSE_CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-gray-600 mb-1 block">Description</label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-rose-500"
                  placeholder="Optional details..."
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-gray-600 flex items-center gap-1 mb-1">
                  <DollarSign size={12} /> Amount *
                </label>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  min="0"
                  className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-rose-500"
                  placeholder="0"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={saving}
                className="w-full bg-rose-600 text-white py-3 rounded-xl font-semibold text-sm hover:bg-rose-700 transition-colors disabled:opacity-50"
              >
                {saving ? 'Saving...' : 'Record Expense'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
