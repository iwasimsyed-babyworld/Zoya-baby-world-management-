import { useState } from 'react';
import { Plus, X, Search, TrendingUp, Package, ArrowDownRight } from 'lucide-react';
import type { Product, Purchase } from '@/types';
import { supabase } from '@/lib/supabase';

interface StockViewProps {
  products: Product[];
  purchases: Purchase[];
  onStockChange: () => void;
  showNotification: (msg: string) => void;
}

function formatCurrency(n: number): string {
  return '₹' + n.toLocaleString('en-IN');
}

export default function StockView({ products, purchases, onStockChange, showNotification }: StockViewProps) {
  const [showModal, setShowModal] = useState(false);
  const [filter, setFilter] = useState('');
  const [saving, setSaving] = useState(false);

  // Form fields
  const [selectedProductId, setSelectedProductId] = useState('');
  const [qty, setQty] = useState('');
  const [purchasePrice, setPurchasePrice] = useState('');
  const [transportCost, setTransportCost] = useState('0');
  const [fittingCost, setFittingCost] = useState('0');
  const [supplier, setSupplier] = useState('');
  const [productSearch, setProductSearch] = useState('');

  const availableProducts = products.filter((p) =>
    p.name.toLowerCase().includes(productSearch.toLowerCase()) ||
    p.code.toLowerCase().includes(productSearch.toLowerCase())
  );

  const selectedProduct = products.find((p) => p.id === selectedProductId);
  const totalLanded = (Number(purchasePrice || 0) + Number(transportCost || 0) + Number(fittingCost || 0)) * Number(qty || 0);

  const openModal = () => {
    setSelectedProductId('');
    setQty('');
    setPurchasePrice('');
    setTransportCost('0');
    setFittingCost('0');
    setSupplier('');
    setProductSearch('');
    setShowModal(true);
  };

  const handleProductSelect = (prod: Product) => {
    setSelectedProductId(prod.id);
    setPurchasePrice(String(prod.purchase_price));
    setSupplier(prod.supplier);
    setProductSearch('');
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProductId || !qty || !purchasePrice) {
      showNotification('Please select a product and enter quantity');
      return;
    }

    const product = products.find((p) => p.id === selectedProductId);
    if (!product) return;

    setSaving(true);
    const qtyNum = Number(qty);
    const pPrice = Number(purchasePrice);
    const tCost = Number(transportCost || 0);
    const fCost = Number(fittingCost || 0);
    const perUnitLanded = pPrice + tCost + fCost;

    try {
      // Insert purchase record
      const { error: purchaseError } = await supabase.from('purchases').insert({
        product_id: selectedProductId,
        product_name: product.name,
        qty: qtyNum,
        purchase_price: pPrice,
        transport_cost: tCost,
        fitting_cost: fCost,
        total_landed: perUnitLanded * qtyNum,
        supplier,
        date: new Date().toISOString().split('T')[0],
      });

      if (purchaseError) throw purchaseError;

      // Update product stock and costs
      const newStock = product.stock + qtyNum;
      const { error: productError } = await supabase
        .from('products')
        .update({
          stock: newStock,
          purchase_price: pPrice,
          transport_cost: tCost,
          fitting_cost: fCost,
          landed_cost: perUnitLanded,
          supplier,
        })
        .eq('id', selectedProductId);

      if (productError) throw productError;

      showNotification(`Stock added: ${qtyNum} units of ${product.name}`);
      setShowModal(false);
      onStockChange();
    } catch (err) {
      showNotification('Error adding stock');
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const filteredPurchases = purchases
    .filter((p) =>
      p.product_name.toLowerCase().includes(filter.toLowerCase()) ||
      p.supplier.toLowerCase().includes(filter.toLowerCase())
    )
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

  // Stock status summary
  const totalUnits = products.reduce((acc, p) => acc + p.stock, 0);
  const lowStockCount = products.filter((p) => p.stock <= p.low_stock).length;
  const outOfStockCount = products.filter((p) => p.stock === 0).length;

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-gray-800">Stock Management</h2>
        <button
          onClick={openModal}
          className="bg-blue-600 text-white px-4 py-2 rounded-xl text-sm font-semibold flex items-center gap-1.5 shadow-sm hover:bg-blue-700 transition-colors"
        >
          <Plus size={18} />
          <span>Restock</span>
        </button>
      </div>

      {/* Stock Summary Cards */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-white p-3 rounded-2xl shadow-sm border border-gray-100 text-center">
          <Package size={18} className="text-blue-500 mx-auto" />
          <p className="text-lg font-bold text-gray-800 mt-1">{totalUnits}</p>
          <p className="text-[10px] text-gray-500">Total Units</p>
        </div>
        <div className="bg-white p-3 rounded-2xl shadow-sm border border-gray-100 text-center">
          <ArrowDownRight size={18} className="text-amber-500 mx-auto" />
          <p className="text-lg font-bold text-amber-600 mt-1">{lowStockCount}</p>
          <p className="text-[10px] text-gray-500">Low Stock</p>
        </div>
        <div className="bg-white p-3 rounded-2xl shadow-sm border border-gray-100 text-center">
          <Package size={18} className="text-rose-500 mx-auto" />
          <p className="text-lg font-bold text-rose-600 mt-1">{outOfStockCount}</p>
          <p className="text-[10px] text-gray-500">Out of Stock</p>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-3 text-gray-400" size={16} />
        <input
          type="text"
          placeholder="Search purchase history..."
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {/* Purchase History */}
      {filteredPurchases.length === 0 ? (
        <div className="text-center py-12">
          <TrendingUp size={32} className="text-gray-300 mx-auto" />
          <p className="text-sm text-gray-400 mt-2">No purchases recorded yet</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredPurchases.map((purchase) => (
            <div key={purchase.id} className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-sm font-bold text-gray-800">{purchase.product_name}</h3>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    <span className="text-[10px] text-gray-400">{purchase.date}</span>
                    <span className="text-[10px] text-gray-400">·</span>
                    <span className="text-[10px] text-gray-500">Qty: {purchase.qty}</span>
                    {purchase.supplier && (
                      <>
                        <span className="text-[10px] text-gray-400">·</span>
                        <span className="text-[10px] text-gray-500">{purchase.supplier}</span>
                      </>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-blue-600">{formatCurrency(purchase.total_landed)}</p>
                  <p className="text-[10px] text-gray-400">{formatCurrency(purchase.purchase_price)}/unit</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Restock Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-end sm:items-center justify-center z-50 p-0 sm:p-4">
          <div className="bg-white w-full sm:max-w-md max-h-[90vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl">
            <div className="sticky top-0 bg-white flex justify-between items-center p-4 border-b border-gray-100 z-10">
              <h3 className="text-lg font-bold text-gray-800">Add Stock</h3>
              <button onClick={() => setShowModal(false)} className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg">
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleSave} className="p-4 space-y-4">
              {/* Product Selection */}
              {selectedProduct ? (
                <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 flex justify-between items-center">
                  <div>
                    <p className="text-sm font-bold text-blue-800">{selectedProduct.name}</p>
                    <p className="text-[10px] text-blue-600">{selectedProduct.code} · Current: {selectedProduct.stock} units</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => { setSelectedProductId(''); setPurchasePrice(''); }}
                    className="text-blue-600 hover:text-blue-800 p-1"
                  >
                    <X size={16} />
                  </button>
                </div>
              ) : (
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1 block">Select Product *</label>
                  <div className="relative mb-2">
                    <Search className="absolute left-3 top-3 text-gray-400" size={16} />
                    <input
                      type="text"
                      placeholder="Search products..."
                      value={productSearch}
                      onChange={(e) => setProductSearch(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div className="max-h-40 overflow-y-auto space-y-1">
                    {availableProducts.map((prod) => (
                      <button
                        key={prod.id}
                        type="button"
                        onClick={() => handleProductSelect(prod)}
                        className="w-full text-left p-2.5 bg-gray-50 hover:bg-blue-50 rounded-xl transition-colors flex justify-between items-center"
                      >
                        <div>
                          <p className="text-sm font-medium text-gray-800">{prod.name}</p>
                          <p className="text-[10px] text-gray-400">{prod.code}</p>
                        </div>
                        <p className="text-xs text-gray-500">Stock: {prod.stock}</p>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Qty */}
              <div>
                <label className="text-xs font-semibold text-gray-600 mb-1 block">Quantity *</label>
                <input
                  type="number"
                  value={qty}
                  onChange={(e) => setQty(e.target.value)}
                  min="1"
                  className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Number of units"
                />
              </div>

              {/* Purchase Price */}
              <div>
                <label className="text-xs font-semibold text-gray-600 mb-1 block">Purchase Price (per unit) *</label>
                <input
                  type="number"
                  value={purchasePrice}
                  onChange={(e) => setPurchasePrice(e.target.value)}
                  className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Transport + Fitting */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1 block">Transport (per unit)</label>
                  <input
                    type="number"
                    value={transportCost}
                    onChange={(e) => setTransportCost(e.target.value)}
                    className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1 block">Fitting (per unit)</label>
                  <input
                    type="number"
                    value={fittingCost}
                    onChange={(e) => setFittingCost(e.target.value)}
                    className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* Supplier */}
              <div>
                <label className="text-xs font-semibold text-gray-600 mb-1 block">Supplier</label>
                <input
                  type="text"
                  value={supplier}
                  onChange={(e) => setSupplier(e.target.value)}
                  className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Supplier name"
                />
              </div>

              {/* Total display */}
              <div className="bg-gradient-to-br from-slate-800 to-slate-900 p-4 rounded-2xl">
                <div className="flex justify-between items-center text-slate-300">
                  <span className="text-xs">Total Landed Cost</span>
                  <span className="text-lg font-bold text-white">{formatCurrency(totalLanded)}</span>
                </div>
                <div className="flex justify-between items-center text-slate-400 mt-2">
                  <span className="text-xs">Per Unit</span>
                  <span className="text-sm font-semibold text-white">{formatCurrency(Number(purchasePrice || 0) + Number(transportCost || 0) + Number(fittingCost || 0))}</span>
                </div>
              </div>

              <button
                type="submit"
                disabled={saving || !selectedProductId}
                className="w-full bg-blue-600 text-white py-3 rounded-xl font-semibold text-sm hover:bg-blue-700 transition-colors disabled:opacity-50"
              >
                {saving ? 'Adding...' : 'Add Stock'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
