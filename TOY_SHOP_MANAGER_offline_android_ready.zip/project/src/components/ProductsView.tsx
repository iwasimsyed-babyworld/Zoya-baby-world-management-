import { useState } from 'react';
import { Plus, Search, Trash2, Edit, Package, X, Tag, DollarSign, Truck, Wrench, Boxes } from 'lucide-react';
import type { Product, ShopSettings } from '@/types';
import { supabase } from '@/lib/supabase';

interface ProductsViewProps {
  products: Product[];
  onProductsChange: () => void;
  settings: ShopSettings;
  showNotification: (msg: string) => void;
}

function formatCurrency(n: number): string {
  return '₹' + n.toLocaleString('en-IN');
}

const CATEGORIES = ['Toys', 'Battery Cars', 'Cycles', 'Accessories', 'Spare Parts', 'Other'];

export default function ProductsView({ products, onProductsChange, settings, showNotification }: ProductsViewProps) {
  const [filter, setFilter] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editProduct, setEditProduct] = useState<Product | null>(null);

  // Form fields
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [category, setCategory] = useState('Toys');
  const [purchasePrice, setPurchasePrice] = useState('');
  const [transportCost, setTransportCost] = useState('0');
  const [fittingCost, setFittingCost] = useState('0');
  const [sellingPrice, setSellingPrice] = useState('');
  const [stock, setStock] = useState('');
  const [lowStock, setLowStock] = useState(String(settings.low_stock_default));
  const [supplier, setSupplier] = useState('');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  const openAddModal = () => {
    setEditProduct(null);
    setName('');
    setCode(`TOY${Math.floor(1000 + Math.random() * 9000)}`);
    setCategory('Toys');
    setPurchasePrice('');
    setTransportCost('0');
    setFittingCost('0');
    setSellingPrice('');
    setStock('');
    setLowStock(String(settings.low_stock_default));
    setSupplier('');
    setNotes('');
    setShowModal(true);
  };

  const openEditModal = (prod: Product) => {
    setEditProduct(prod);
    setName(prod.name);
    setCode(prod.code);
    setCategory(prod.category);
    setPurchasePrice(String(prod.purchase_price));
    setTransportCost(String(prod.transport_cost));
    setFittingCost(String(prod.fitting_cost));
    setSellingPrice(String(prod.selling_price));
    setStock(String(prod.stock));
    setLowStock(String(prod.low_stock));
    setSupplier(prod.supplier);
    setNotes(prod.notes);
    setShowModal(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !purchasePrice || !sellingPrice || !stock) {
      showNotification('Please fill all required fields');
      return;
    }

    setSaving(true);
    const pPrice = Number(purchasePrice);
    const tCost = Number(transportCost || 0);
    const fCost = Number(fittingCost || 0);
    const landedCost = pPrice + tCost + fCost;

    const payload = {
      code,
      name,
      category,
      purchase_price: pPrice,
      transport_cost: tCost,
      fitting_cost: fCost,
      landed_cost: landedCost,
      selling_price: Number(sellingPrice),
      stock: Number(stock),
      low_stock: Number(lowStock),
      supplier,
      notes,
    };

    try {
      if (editProduct) {
        const { error } = await supabase.from('products').update(payload).eq('id', editProduct.id);
        if (error) throw error;
        showNotification('Product updated successfully');
      } else {
        const { error } = await supabase.from('products').insert({ ...payload, date_added: new Date().toISOString().split('T')[0] });
        if (error) throw error;
        showNotification('Product added successfully');
      }
      setShowModal(false);
      onProductsChange();
    } catch (err) {
      showNotification('Error saving product');
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Delete this product? This cannot be undone.')) return;
    try {
      const { error } = await supabase.from('products').delete().eq('id', id);
      if (error) throw error;
      showNotification('Product deleted');
      onProductsChange();
    } catch (err) {
      showNotification('Error deleting product');
      console.error(err);
    }
  };

  const filteredProducts = products.filter((p) =>
    p.name.toLowerCase().includes(filter.toLowerCase()) ||
    p.code.toLowerCase().includes(filter.toLowerCase()) ||
    p.category.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-gray-800">Products</h2>
        <button
          onClick={openAddModal}
          className="bg-blue-600 text-white px-4 py-2 rounded-xl text-sm font-semibold flex items-center gap-1.5 shadow-sm hover:bg-blue-700 transition-colors"
        >
          <Plus size={18} />
          <span>Add</span>
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-3 text-gray-400" size={16} />
        <input
          type="text"
          placeholder="Search by name, code, or category..."
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {/* Product List */}
      {filteredProducts.length === 0 ? (
        <div className="text-center py-12">
          <Package size={32} className="text-gray-300 mx-auto" />
          <p className="text-sm text-gray-400 mt-2">No products found</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredProducts.map((prod) => (
            <div key={prod.id} className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-gray-800">{prod.name}</h3>
                    <span className="text-[10px] font-medium text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md">{prod.code}</span>
                  </div>
                  <p className="text-xs text-gray-500 mt-0.5">{prod.category}</p>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => openEditModal(prod)} className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                    <Edit size={16} />
                  </button>
                  <button onClick={() => handleDelete(prod.id)} className="p-2 text-gray-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors">
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
              <div className="grid grid-cols-4 gap-2 mt-3">
                <div>
                  <p className="text-[10px] text-gray-400">Cost</p>
                  <p className="text-xs font-semibold text-gray-700">{formatCurrency(prod.landed_cost)}</p>
                </div>
                <div>
                  <p className="text-[10px] text-gray-400">Price</p>
                  <p className="text-xs font-semibold text-blue-600">{formatCurrency(prod.selling_price)}</p>
                </div>
                <div>
                  <p className="text-[10px] text-gray-400">Margin</p>
                  <p className="text-xs font-semibold text-emerald-600">{formatCurrency(prod.selling_price - prod.landed_cost)}</p>
                </div>
                <div>
                  <p className="text-[10px] text-gray-400">Stock</p>
                  <p className={`text-xs font-bold ${prod.stock <= prod.low_stock ? 'text-rose-600' : 'text-gray-700'}`}>{prod.stock} units</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-end sm:items-center justify-center z-50 p-0 sm:p-4">
          <div className="bg-white w-full sm:max-w-md max-h-[90vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl">
            <div className="sticky top-0 bg-white flex justify-between items-center p-4 border-b border-gray-100 z-10">
              <h3 className="text-lg font-bold text-gray-800">{editProduct ? 'Edit Product' : 'Add Product'}</h3>
              <button onClick={() => setShowModal(false)} className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg">
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleSave} className="p-4 space-y-4">
              {/* Name */}
              <div>
                <label className="text-xs font-semibold text-gray-600 flex items-center gap-1 mb-1">
                  <Package size={12} /> Product Name *
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g. Battery Car Big Wheels"
                  required
                />
              </div>

              {/* Code + Category */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-gray-600 flex items-center gap-1 mb-1">
                    <Tag size={12} /> Product Code
                  </label>
                  <input
                    type="text"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1 block">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Purchase Price */}
              <div>
                <label className="text-xs font-semibold text-gray-600 flex items-center gap-1 mb-1">
                  <DollarSign size={12} /> Purchase Price *
                </label>
                <input
                  type="number"
                  value={purchasePrice}
                  onChange={(e) => setPurchasePrice(e.target.value)}
                  className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="0"
                  required
                />
              </div>

              {/* Transport + Fitting */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-gray-600 flex items-center gap-1 mb-1">
                    <Truck size={12} /> Transport Cost
                  </label>
                  <input
                    type="number"
                    value={transportCost}
                    onChange={(e) => setTransportCost(e.target.value)}
                    className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-600 flex items-center gap-1 mb-1">
                    <Wrench size={12} /> Fitting Cost
                  </label>
                  <input
                    type="number"
                    value={fittingCost}
                    onChange={(e) => setFittingCost(e.target.value)}
                    className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* Landed cost display */}
              <div className="bg-blue-50 border border-blue-100 rounded-xl p-3 flex justify-between items-center">
                <span className="text-xs font-medium text-blue-700">Calculated Landed Cost</span>
                <span className="text-sm font-bold text-blue-700">
                  {formatCurrency(Number(purchasePrice || 0) + Number(transportCost || 0) + Number(fittingCost || 0))}
                </span>
              </div>

              {/* Selling Price + Stock */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-gray-600 flex items-center gap-1 mb-1">
                    <DollarSign size={12} /> Selling Price *
                  </label>
                  <input
                    type="number"
                    value={sellingPrice}
                    onChange={(e) => setSellingPrice(e.target.value)}
                    className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="0"
                    required
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-600 flex items-center gap-1 mb-1">
                    <Boxes size={12} /> Stock *
                  </label>
                  <input
                    type="number"
                    value={stock}
                    onChange={(e) => setStock(e.target.value)}
                    className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="0"
                    required
                  />
                </div>
              </div>

              {/* Low stock threshold + supplier */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1 block">Low Stock Alert At</label>
                  <input
                    type="number"
                    value={lowStock}
                    onChange={(e) => setLowStock(e.target.value)}
                    className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1 block">Supplier</label>
                  <input
                    type="text"
                    value={supplier}
                    onChange={(e) => setSupplier(e.target.value)}
                    className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Supplier name"
                  />
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="text-xs font-semibold text-gray-600 mb-1 block">Notes</label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                  className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                  placeholder="Optional notes..."
                />
              </div>

              <button
                type="submit"
                disabled={saving}
                className="w-full bg-blue-600 text-white py-3 rounded-xl font-semibold text-sm hover:bg-blue-700 transition-colors disabled:opacity-50"
              >
                {saving ? 'Saving...' : editProduct ? 'Update Product' : 'Add Product'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
