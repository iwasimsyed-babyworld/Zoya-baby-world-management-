import { useState } from 'react';
import { Plus, ShoppingCart, X, Search, Trash2, TrendingUp } from 'lucide-react';
import type { Product, Sale, ShopSettings } from '@/types';
import { supabase } from '@/lib/supabase';

interface SalesViewProps {
  products: Product[];
  sales: Sale[];
  settings: ShopSettings;
  onSalesChange: () => void;
  showNotification: (msg: string) => void;
}

function formatCurrency(n: number): string {
  return '₹' + n.toLocaleString('en-IN');
}

const PAYMENT_MODES = ['Cash', 'Card', 'UPI', 'Credit'];

export default function SalesView({ products, sales, settings, onSalesChange, showNotification }: SalesViewProps) {
  const [showModal, setShowModal] = useState(false);
  const [filter, setFilter] = useState('');
  const [saving, setSaving] = useState(false);

  // Form fields
  const [selectedProductId, setSelectedProductId] = useState('');
  const [qty, setQty] = useState('1');
  const [unitPrice, setUnitPrice] = useState('');
  const [discount, setDiscount] = useState('0');
  const [customerName, setCustomerName] = useState('');
  const [paymentMode, setPaymentMode] = useState('Cash');
  const [productSearch, setProductSearch] = useState('');

  const availableProducts = products.filter((p) =>
    p.name.toLowerCase().includes(productSearch.toLowerCase()) ||
    p.code.toLowerCase().includes(productSearch.toLowerCase())
  );

  const selectedProduct = products.find((p) => p.id === selectedProductId);
  const finalAmount = Math.max(0, Number(unitPrice || 0) * Number(qty || 0) - Number(discount || 0));
  const grossProfit = finalAmount - (selectedProduct ? selectedProduct.landed_cost * Number(qty || 0) : 0);

  const openModal = () => {
    setSelectedProductId('');
    setQty('1');
    setUnitPrice('');
    setDiscount('0');
    setCustomerName('');
    setPaymentMode('Cash');
    setProductSearch('');
    setShowModal(true);
  };

  const handleProductSelect = (prod: Product) => {
    setSelectedProductId(prod.id);
    setUnitPrice(String(prod.selling_price));
    setProductSearch('');
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProductId || !qty || !unitPrice) {
      showNotification('Please select a product and enter quantity');
      return;
    }

    const product = products.find((p) => p.id === selectedProductId);
    if (!product) return;

    const qtyNum = Number(qty);
    if (!settings.allow_negative_stock && qtyNum > product.stock) {
      showNotification(`Insufficient stock! Only ${product.stock} units available`);
      return;
    }

    setSaving(true);
    try {
      // Insert sale record
      const { error: saleError } = await supabase.from('sales').insert({
        product_id: selectedProductId,
        product_name: product.name,
        qty: qtyNum,
        unit_price: Number(unitPrice),
        discount: Number(discount || 0),
        final_amount: finalAmount,
        gross_profit: grossProfit,
        customer_name: customerName,
        payment_mode: paymentMode,
        date: new Date().toISOString().split('T')[0],
      });

      if (saleError) throw saleError;

      // Decrement stock
      const newStock = product.stock - qtyNum;
      const { error: stockError } = await supabase
        .from('products')
        .update({ stock: newStock })
        .eq('id', selectedProductId);

      if (stockError) throw stockError;

      showNotification(`Sale recorded: ${formatCurrency(finalAmount)}`);
      setShowModal(false);
      onSalesChange();
    } catch (err) {
      showNotification('Error recording sale');
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string, productId: string | null, qty: number) => {
    if (!window.confirm('Delete this sale? Stock will be restored.')) return;
    try {
      const { error } = await supabase.from('sales').delete().eq('id', id);
      if (error) throw error;

      // Restore stock
      if (productId) {
        const product = products.find((p) => p.id === productId);
        if (product) {
          await supabase.from('products').update({ stock: product.stock + qty }).eq('id', productId);
        }
      }

      showNotification('Sale deleted, stock restored');
      onSalesChange();
    } catch (err) {
      showNotification('Error deleting sale');
      console.error(err);
    }
  };

  const filteredSales = sales
    .filter((s) =>
      s.product_name.toLowerCase().includes(filter.toLowerCase()) ||
      s.customer_name.toLowerCase().includes(filter.toLowerCase())
    )
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-gray-800">Sales</h2>
        <button
          onClick={openModal}
          className="bg-emerald-600 text-white px-4 py-2 rounded-xl text-sm font-semibold flex items-center gap-1.5 shadow-sm hover:bg-emerald-700 transition-colors"
        >
          <Plus size={18} />
          <span>New Sale</span>
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-3 text-gray-400" size={16} />
        <input
          type="text"
          placeholder="Search sales history..."
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
        />
      </div>

      {/* Sales List */}
      {filteredSales.length === 0 ? (
        <div className="text-center py-12">
          <ShoppingCart size={32} className="text-gray-300 mx-auto" />
          <p className="text-sm text-gray-400 mt-2">No sales recorded yet</p>
          <p className="text-xs text-gray-400">Tap "New Sale" to record your first sale</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredSales.map((sale) => (
            <div key={sale.id} className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <h3 className="text-sm font-bold text-gray-800">{sale.product_name}</h3>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    <span className="text-[10px] text-gray-400">{sale.date}</span>
                    <span className="text-[10px] text-gray-400">·</span>
                    <span className="text-[10px] text-gray-500">Qty: {sale.qty}</span>
                    {sale.customer_name && (
                      <>
                        <span className="text-[10px] text-gray-400">·</span>
                        <span className="text-[10px] text-gray-500">{sale.customer_name}</span>
                      </>
                    )}
                    <span className="text-[10px] font-medium text-gray-500 bg-gray-100 px-1.5 py-0.5 rounded">{sale.payment_mode}</span>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <div className="text-right">
                    <p className="text-sm font-bold text-emerald-600">{formatCurrency(sale.final_amount)}</p>
                    <p className="text-[10px] text-emerald-600 font-medium flex items-center gap-0.5 justify-end">
                      <TrendingUp size={10} /> +{formatCurrency(sale.gross_profit)}
                    </p>
                  </div>
                  <button
                    onClick={() => handleDelete(sale.id, sale.product_id, sale.qty)}
                    className="p-1.5 text-gray-300 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
              {sale.discount > 0 && (
                <p className="text-[10px] text-gray-400 mt-1">Discount: {formatCurrency(sale.discount)}</p>
              )}
            </div>
          ))}
        </div>
      )}

      {/* New Sale Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-end sm:items-center justify-center z-50 p-0 sm:p-4">
          <div className="bg-white w-full sm:max-w-md max-h-[90vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl">
            <div className="sticky top-0 bg-white flex justify-between items-center p-4 border-b border-gray-100 z-10">
              <h3 className="text-lg font-bold text-gray-800">New Sale</h3>
              <button onClick={() => setShowModal(false)} className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg">
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleSave} className="p-4 space-y-4">
              {/* Product Selection */}
              {selectedProduct ? (
                <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 flex justify-between items-center">
                  <div>
                    <p className="text-sm font-bold text-emerald-800">{selectedProduct.name}</p>
                    <p className="text-[10px] text-emerald-600">{selectedProduct.code} · Stock: {selectedProduct.stock}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => { setSelectedProductId(''); setUnitPrice(''); }}
                    className="text-emerald-600 hover:text-emerald-800 p-1"
                  >
                    <X size={16} />
                  </button>
                </div>
              ) : (
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1 block">Select Product *</label>
                  <div className="relative mb-2">
                    <Search className="absolute left-3 top-3 text-gray-400" size={16} />
                    <input
                      type="text"
                      placeholder="Search products..."
                      value={productSearch}
                      onChange={(e) => setProductSearch(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <div className="max-h-40 overflow-y-auto space-y-1">
                    {availableProducts.map((prod) => (
                      <button
                        key={prod.id}
                        type="button"
                        onClick={() => handleProductSelect(prod)}
                        className="w-full text-left p-2.5 bg-gray-50 hover:bg-emerald-50 rounded-xl transition-colors flex justify-between items-center"
                      >
                        <div>
                          <p className="text-sm font-medium text-gray-800">{prod.name}</p>
                          <p className="text-[10px] text-gray-400">{prod.code} · {prod.category}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs font-bold text-emerald-600">{formatCurrency(prod.selling_price)}</p>
                          <p className="text-[10px] text-gray-400">Stock: {prod.stock}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Qty + Unit Price */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1 block">Quantity *</label>
                  <input
                    type="number"
                    value={qty}
                    onChange={(e) => setQty(e.target.value)}
                    min="1"
                    className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1 block">Unit Price *</label>
                  <input
                    type="number"
                    value={unitPrice}
                    onChange={(e) => setUnitPrice(e.target.value)}
                    className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {/* Discount */}
              <div>
                <label className="text-xs font-semibold text-gray-600 mb-1 block">Discount (₹)</label>
                <input
                  type="number"
                  value={discount}
                  onChange={(e) => setDiscount(e.target.value)}
                  min="0"
                  className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              {/* Customer + Payment */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1 block">Customer (optional)</label>
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="Walk-in"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1 block">Payment</label>
                  <select
                    value={paymentMode}
                    onChange={(e) => setPaymentMode(e.target.value)}
                    className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    {PAYMENT_MODES.map((mode) => (
                      <option key={mode} value={mode}>{mode}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Summary */}
              <div className="bg-gradient-to-br from-slate-800 to-slate-900 p-4 rounded-2xl">
                <div className="flex justify-between items-center text-slate-300">
                  <span className="text-xs">Total Amount</span>
                  <span className="text-lg font-bold text-white">{formatCurrency(finalAmount)}</span>
                </div>
                <div className="flex justify-between items-center text-slate-400 mt-2">
                  <span className="text-xs">Gross Profit</span>
                  <span className={`text-sm font-bold ${grossProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>{formatCurrency(grossProfit)}</span>
                </div>
              </div>

              <button
                type="submit"
                disabled={saving || !selectedProductId}
                className="w-full bg-emerald-600 text-white py-3 rounded-xl font-semibold text-sm hover:bg-emerald-700 transition-colors disabled:opacity-50"
              >
                {saving ? 'Recording...' : 'Record Sale'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
