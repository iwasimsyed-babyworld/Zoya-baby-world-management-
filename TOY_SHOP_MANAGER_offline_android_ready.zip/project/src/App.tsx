import { useState, useEffect, useCallback } from 'react';
import { Home, Package, ShoppingCart, TrendingUp, DollarSign, Settings, FileText, Smartphone } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Product, Sale, Purchase, Expense, ShopSettings, TabId } from '@/types';
import DashboardView from '@/components/DashboardView';
import ProductsView from '@/components/ProductsView';
import SalesView from '@/components/SalesView';
import StockView from '@/components/StockView';
import ExpensesView from '@/components/ExpensesView';
import ReportsView from '@/components/ReportsView';
import SettingsView from '@/components/SettingsView';

const DEFAULT_SETTINGS: ShopSettings = {
  id: 1,
  shop_name: 'My Toy & Cycle Shop',
  shop_address: 'Main Bazaar, India',
  phone: '9876543210',
  gst: '',
  allow_negative_stock: false,
  low_stock_default: 2,
  updated_at: '',
};

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>('dashboard');
  const [products, setProducts] = useState<Product[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [settings, setSettings] = useState<ShopSettings>(DEFAULT_SETTINGS);
  const [notification, setNotification] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  const loadAll = useCallback(async () => {
    try {
      const [productsRes, salesRes, purchasesRes, expensesRes, settingsRes] = await Promise.all([
        supabase.from('products').select('*').order('created_at', { ascending: false }),
        supabase.from('sales').select('*').order('created_at', { ascending: false }),
        supabase.from('purchases').select('*').order('created_at', { ascending: false }),
        supabase.from('expenses').select('*').order('created_at', { ascending: false }),
        supabase.from('settings').select('*').eq('id', 1).maybeSingle(),
      ]);

      if (productsRes.error) throw productsRes.error;
      if (salesRes.error) throw salesRes.error;
      if (purchasesRes.error) throw purchasesRes.error;
      if (expensesRes.error) throw expensesRes.error;

      setProducts(productsRes.data || []);
      setSales(salesRes.data || []);
      setPurchases(purchasesRes.data || []);
      setExpenses(expensesRes.data || []);
      if (settingsRes.data) {
        setSettings(settingsRes.data as ShopSettings);
      }
    } catch (err) {
      console.error('Error loading data:', err);
      showNotification('Unable to load local shop data.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  // Calculations
  const todayStr = new Date().toISOString().split('T')[0];
  const currentMonthStr = todayStr.substring(0, 7);

  const todaySalesList = sales.filter((s) => s.date === todayStr);
  const todayRevenue = todaySalesList.reduce((acc, s) => acc + s.final_amount, 0);
  const todayGrossProfit = todaySalesList.reduce((acc, s) => acc + s.gross_profit, 0);
  const todayExpensesList = expenses.filter((e) => e.date === todayStr);
  const todayExpenseTotal = todayExpensesList.reduce((acc, e) => acc + e.amount, 0);
  const todayNetProfit = todayGrossProfit - todayExpenseTotal;

  const monthSalesList = sales.filter((s) => s.date.startsWith(currentMonthStr));
  const monthRevenue = monthSalesList.reduce((acc, s) => acc + s.final_amount, 0);
  const monthGrossProfit = monthSalesList.reduce((acc, s) => acc + s.gross_profit, 0);
  const monthExpensesList = expenses.filter((e) => e.date.startsWith(currentMonthStr));
  const monthExpenseTotal = monthExpensesList.reduce((acc, e) => acc + e.amount, 0);
  const monthNetProfit = monthGrossProfit - monthExpenseTotal;

  const totalStockValue = products.reduce((acc, p) => acc + p.stock * p.landed_cost, 0);
  const totalUnitsInStock = products.reduce((acc, p) => acc + p.stock, 0);
  const lowStockItems = products.filter((p) => p.stock <= p.low_stock);
  const recentSales = sales.slice(0, 5);

  if (loading) {
    return (
      <div className="flex flex-col h-screen bg-gray-50 items-center justify-center max-w-md mx-auto">
        <div className="animate-pulse">
          <Package size={48} className="text-blue-500" />
        </div>
        <p className="text-sm text-gray-500 mt-4">Loading your shop data...</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-gray-50 text-gray-900 max-w-md mx-auto shadow-2xl border-x border-gray-200">
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-4 py-4 flex justify-between items-center shadow-md">
        <div>
          <h1 className="text-lg font-bold tracking-wide">{settings.shop_name}</h1>
          <p className="text-xs text-blue-100">Toy & Cycle Inventory Manager</p>
        </div>
        <div className="bg-blue-800/50 px-3 py-1 rounded-full text-[10px] font-semibold flex items-center gap-1 border border-blue-400/30">
          <Smartphone size={10} />
          <span>OFFLINE MODE</span>
        </div>
      </header>

      {/* Notification */}
      {notification && (
        <div className="bg-emerald-500 text-white text-center py-2.5 text-sm font-medium animate-pulse">
          {notification}
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-4 pb-20">
        {activeTab === 'dashboard' && (
          <DashboardView
            todayRevenue={todayRevenue}
            todayGrossProfit={todayGrossProfit}
            todayExpenseTotal={todayExpenseTotal}
            todayNetProfit={todayNetProfit}
            monthRevenue={monthRevenue}
            monthGrossProfit={monthGrossProfit}
            monthExpenseTotal={monthExpenseTotal}
            monthNetProfit={monthNetProfit}
            totalStockValue={totalStockValue}
            totalUnitsInStock={totalUnitsInStock}
            lowStockItems={lowStockItems}
            recentSales={recentSales}
          />
        )}
        {activeTab === 'products' && (
          <ProductsView
            products={products}
            onProductsChange={loadAll}
            settings={settings}
            showNotification={showNotification}
          />
        )}
        {activeTab === 'sales' && (
          <SalesView
            products={products}
            sales={sales}
            settings={settings}
            onSalesChange={loadAll}
            showNotification={showNotification}
          />
        )}
        {activeTab === 'stock' && (
          <StockView
            products={products}
            purchases={purchases}
            onStockChange={loadAll}
            showNotification={showNotification}
          />
        )}
        {activeTab === 'expenses' && (
          <ExpensesView
            expenses={expenses}
            onExpensesChange={loadAll}
            showNotification={showNotification}
          />
        )}
        {activeTab === 'reports' && (
          <ReportsView
            sales={sales}
            expenses={expenses}
            products={products}
            purchases={purchases}
          />
        )}
        {activeTab === 'settings' && (
          <SettingsView
            settings={settings}
            onSettingsChange={loadAll}
            showNotification={showNotification}
          />
        )}
      </main>

      {/* Bottom Navigation */}
      <nav className="bg-white border-t border-gray-200 flex justify-around items-center h-16 fixed bottom-0 max-w-md w-full z-10 shadow-lg">
        <NavButton active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} icon={<Home size={20} />} label="Home" />
        <NavButton active={activeTab === 'sales'} onClick={() => setActiveTab('sales')} icon={<ShoppingCart size={20} />} label="Sales" />
        <NavButton active={activeTab === 'products'} onClick={() => setActiveTab('products')} icon={<Package size={20} />} label="Products" />
        <NavButton active={activeTab === 'stock'} onClick={() => setActiveTab('stock')} icon={<TrendingUp size={20} />} label="Stock" />
        <NavButton active={activeTab === 'expenses'} onClick={() => setActiveTab('expenses')} icon={<DollarSign size={20} />} label="Expenses" />
        <NavButton active={activeTab === 'reports'} onClick={() => setActiveTab('reports')} icon={<FileText size={20} />} label="Reports" />
        <NavButton active={activeTab === 'settings'} onClick={() => setActiveTab('settings')} icon={<Settings size={20} />} label="Settings" />
      </nav>
    </div>
  );
}

interface NavButtonProps {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}

function NavButton({ active, onClick, icon, label }: NavButtonProps) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center justify-center flex-1 h-full transition-colors ${
        active ? 'text-blue-600 font-bold' : 'text-gray-500 hover:text-gray-700'
      }`}
    >
      {icon}
      <span className="text-[10px] mt-1">{label}</span>
    </button>
  );
}
