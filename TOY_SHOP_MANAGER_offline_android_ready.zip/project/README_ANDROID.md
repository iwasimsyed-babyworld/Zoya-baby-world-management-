# Toy Shop Manager — Android build

This project is prepared to run as a standalone Android app using Capacitor.

## Offline behavior

The previous Supabase data layer has been replaced with a local persistent store backed by the device's browser storage. Product, sales, purchase, expense and settings data remain on the phone and do not require Netlify or Supabase.

The UI is bundled into the APK. The app does not redirect to the Netlify website.

## Build

The included GitHub Actions workflow (`.github/workflows/build-android.yml`) installs dependencies, builds the app, creates the Android project, and produces a debug APK.

After the workflow finishes, the APK is available as the workflow artifact named `toy-shop-manager-debug-apk`.

## Important

This version is intentionally offline-first. Cloud backup/synchronization is not included yet.
