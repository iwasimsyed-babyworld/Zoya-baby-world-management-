# Toy Shop Manager — Android offline + Google Drive backup

This version is intentionally offline-first. Shop data is stored locally on the device and the app does not require Netlify or a live database to operate.

## Google Drive backup and restore

The app now includes **Backup** and **Restore** in Settings.

### Backup
1. Open **Settings → Cloud Backup → Backup**.
2. Android's share menu opens when supported.
3. Choose **Google Drive / Save to Drive** and save the JSON backup.

If the share menu is unavailable, the app downloads the backup JSON. Upload that file to Google Drive manually.

### Restore on another phone
1. Install the same APK.
2. Open **Settings → Cloud Backup → Restore**.
3. Android's file picker opens.
4. Choose the backup JSON from Google Drive.
5. Confirm the restore.

Restoring replaces the local data on that phone with the backup. Keep an additional copy of important backups.

## Important limitation

This is **cloud backup/restore**, not live two-phone synchronization. If you need both phones editing the shop at the same time with automatic synchronization, use a cloud database such as Supabase instead.

## Build

The included GitHub Actions workflow builds the standalone APK.
