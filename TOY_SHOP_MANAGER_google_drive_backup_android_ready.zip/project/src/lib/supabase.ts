// Offline local data store.
// Kept behind the existing "supabase" interface so the app's screens do not
// need a rewrite. No network connection is used.
type Row = Record<string, any>;

const DB_KEY = 'toy-shop-manager-db-v1';

const defaults: Record<string, Row[]> = {
  products: [],
  sales: [],
  purchases: [],
  expenses: [],
  settings: [{
    id: 1,
    shop_name: 'My Toy & Cycle Shop',
    shop_address: 'Main Bazaar, India',
    phone: '9876543210',
    gst: '',
    allow_negative_stock: false,
    low_stock_default: 2,
    updated_at: new Date().toISOString(),
  }],
};

function readDb(): Record<string, Row[]> {
  try {
    const raw = localStorage.getItem(DB_KEY);
    if (!raw) return structuredClone(defaults);
    const parsed = JSON.parse(raw);
    return { ...structuredClone(defaults), ...parsed };
  } catch {
    return structuredClone(defaults);
  }
}

function writeDb(db: Record<string, Row[]>) {
  localStorage.setItem(DB_KEY, JSON.stringify(db));
}

function uuid() {
  return crypto.randomUUID ? crypto.randomUUID() :
    'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
}

class Query {
  private table: string;
  private action: 'select'|'insert'|'update'|'delete' = 'select';
  private payload: Row | Row[] | null = null;
  private filters: { op: 'eq'|'neq'; key: string; value: any }[] = [];
  private orderKey?: string;
  private ascending = true;

  constructor(table: string) { this.table = table; }

  select(_columns = '*') { this.action = 'select'; return this; }
  insert(payload: Row | Row[]) { this.action = 'insert'; this.payload = payload; return this; }
  update(payload: Row) { this.action = 'update'; this.payload = payload; return this; }
  delete() { this.action = 'delete'; return this; }
  eq(key: string, value: any) { this.filters.push({ op: 'eq', key, value }); return this; }
  neq(key: string, value: any) { this.filters.push({ op: 'neq', key, value }); return this; }
  order(key: string, opts?: { ascending?: boolean }) {
    this.orderKey = key; this.ascending = opts?.ascending ?? true; return this;
  }
  maybeSingle() { return this.execute().then(r => ({ ...r, data: r.data?.[0] ?? null })); }

  async execute(): Promise<{ data: any; error: any }> {
    try {
      const db = readDb();
      if (!db[this.table]) db[this.table] = [];
      let rows = db[this.table];

      const matches = (row: Row) => this.filters.every(f =>
        f.op === 'eq' ? row[f.key] === f.value : row[f.key] !== f.value
      );

      if (this.action === 'select') {
        let data = rows.filter(matches).map(r => ({ ...r }));
        if (this.orderKey) {
          data.sort((a, b) => {
            const av = a[this.orderKey!], bv = b[this.orderKey!];
            const cmp = av > bv ? 1 : av < bv ? -1 : 0;
            return this.ascending ? cmp : -cmp;
          });
        }
        return { data, error: null };
      }

      if (this.action === 'insert') {
        const input = Array.isArray(this.payload) ? this.payload : [this.payload!];
        const now = new Date().toISOString();
        const added = input.map(item => ({
          ...item,
          id: item.id ?? uuid(),
          created_at: item.created_at ?? now,
        }));
        db[this.table].push(...added);
        writeDb(db);
        return { data: added, error: null };
      }

      const indexes = rows.map((r, i) => matches(r) ? i : -1).filter(i => i >= 0);

      if (this.action === 'update') {
        indexes.forEach(i => { rows[i] = { ...rows[i], ...this.payload }; });
        writeDb(db);
        return { data: indexes.map(i => ({ ...rows[i] })), error: null };
      }

      if (this.action === 'delete') {
        const removed = indexes.map(i => ({ ...rows[i] }));
        db[this.table] = rows.filter((_r, i) => !indexes.includes(i));
        writeDb(db);
        return { data: removed, error: null };
      }

      return { data: [], error: null };
    } catch (error) {
      console.error('Local database error:', error);
      return { data: null, error };
    }
  }

  then<TResult1 = {data:any,error:any}, TResult2 = never>(
    onfulfilled?: ((value: {data:any,error:any}) => TResult1 | PromiseLike<TResult1>) | null,
    onrejected?: ((reason:any) => TResult2 | PromiseLike<TResult2>) | null
  ): Promise<TResult1 | TResult2> {
    return this.execute().then(onfulfilled as any, onrejected as any);
  }
}


export interface ShopBackup {
  backupVersion: 1;
  app: 'toy-shop-manager';
  exportedAt: string;
  data: Record<string, Row[]>;
}

export function exportLocalBackup(): ShopBackup {
  return {
    backupVersion: 1,
    app: 'toy-shop-manager',
    exportedAt: new Date().toISOString(),
    data: readDb(),
  };
}

export function importLocalBackup(backup: unknown): void {
  if (!backup || typeof backup !== 'object') throw new Error('Invalid backup file');
  const b = backup as Partial<ShopBackup>;
  if (b.app !== 'toy-shop-manager' || b.backupVersion !== 1 || !b.data || typeof b.data !== 'object') {
    throw new Error('This is not a valid Toy Shop Manager backup');
  }

  const requiredTables = ['products', 'sales', 'purchases', 'expenses', 'settings'];
  for (const table of requiredTables) {
    if (!Array.isArray((b.data as Record<string, unknown>)[table])) {
      throw new Error(`Backup is missing the ${table} data`);
    }
  }

  const db: Record<string, Row[]> = {};
  for (const table of requiredTables) {
    db[table] = (b.data as Record<string, Row[]>)[table].map(row => ({ ...row }));
  }
  writeDb(db);
}

export const supabase = {
  from(table: string) {
    return new Query(table);
  },
};
