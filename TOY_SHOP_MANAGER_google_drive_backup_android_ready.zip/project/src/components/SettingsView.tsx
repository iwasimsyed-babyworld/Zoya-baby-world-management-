import { useState } from 'react';
import { Settings as SettingsIcon, Store, Phone, MapPin, FileText, AlertTriangle, ShieldCheck, Save, Database, Trash2, Upload, Download, Cloud } from 'lucide-react';
import type { Product, Sale, Purchase, Expense, ShopSettings } from '@/types';
import { supabase, exportLocalBackup, importLocalBackup } from '@/lib/supabase';

interface SettingsViewProps {
  settings: ShopSettings;
  onSettingsChange: () => void;
  showNotification: (msg: string) => void;
}

export default function SettingsView({ settings, onSettingsChange, showNotification }: SettingsViewProps) {
  const [saving, setSaving] = useState(false);
  const [shopName, setShopName] = useState(settings.shop_name);
  const [shopAddress, setShopAddress] = useState(settings.shop_address);
  const [phone, setPhone] = useState(settings.phone);
  const [gst, setGst] = useState(settings.gst);
  const [allowNegativeStock, setAllowNegativeStock] = useState(settings.allow_negative_stock);
  const [lowStockDefault, setLowStockDefault] = useState(String(settings.low_stock_default));

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const { error } = await supabase.from('settings').update({
        shop_name: shopName,
        shop_address: shopAddress,
        phone,
        gst,
        allow_negative_stock: allowNegativeStock,
        low_stock_default: Number(lowStockDefault),
        updated_at: new Date().toISOString(),
      }).eq('id', 1);

      if (error) throw error;
      showNotification('Settings saved successfully');
      onSettingsChange();
    } catch (err) {
      showNotification('Error saving settings');
      console.error(err);
    } finally {
      setSaving(false);
    }
  };


  const handleBackup = async () => {
    try {
      const backup = exportLocalBackup();
      const fileName = `toy-shop-manager-backup-${new Date().toISOString().slice(0, 10)}.json`;
      const file = new File([JSON.stringify(backup, null, 2)], fileName, { type: 'application/json' });

      if (navigator.share && typeof navigator.canShare === 'function' && navigator.canShare({ files: [file] })) {
        await navigator.share({
          title: 'Toy Shop Manager Backup',
          text: 'Save this backup to Google Drive or another secure location.',
          files: [file],
        });
        showNotification('Backup ready to save. Choose Google Drive if available.');
        return;
      }

      const url = URL.createObjectURL(file);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = fileName;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      URL.revokeObjectURL(url);
      showNotification('Backup file downloaded. Upload it to Google Drive.');
    } catch (err) {
      if ((err as DOMException)?.name === 'AbortError') return;
      console.error(err);
      showNotification('Unable to create backup');
    }
  };

  const handleRestore = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;

    if (!window.confirm('Restore this backup? Current data on this phone will be replaced by the backup.')) return;

    try {
      const text = await file.text();
      importLocalBackup(JSON.parse(text));
      showNotification('Backup restored successfully. Reloading...');
      setTimeout(() => window.location.reload(), 700);
    } catch (err) {
      console.error(err);
      showNotification('Invalid or damaged backup file');
    }
  };

  const handleClearData = async () => {
    if (!window.confirm('This will permanently delete ALL products, sales, purchases, and expenses. This cannot be undone. Are you absolutely sure?')) return;
    if (!window.confirm('Last warning: This deletes everything. Continue?')) return;

    try {
      await supabase.from('sales').delete().neq('id', '00000000-0000-0000-0000-000000000000');
      await supabase.from('purchases').delete().neq('id', '00000000-0000-0000-0000-000000000000');
      await supabase.from('expenses').delete().neq('id', '00000000-0000-0000-0000-000000000000');
      await supabase.from('products').delete().neq('id', '00000000-0000-0000-0000-000000000000');
      showNotification('All data cleared');
      onSettingsChange();
    } catch (err) {
      showNotification('Error clearing data');
      console.error(err);
    }
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-gray-800">Settings</h2>

      {/* Shop Info */}
      <form onSubmit={handleSave} className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 space-y-4">
        <div className="flex items-center gap-2 text-gray-700">
          <Store size={18} className="text-blue-600" />
          <h3 className="text-sm font-bold">Shop Information</h3>
        </div>

        <div>
          <label className="text-xs font-semibold text-gray-600 mb-1 block">Shop Name</label>
          <input
            type="text"
            value={shopName}
            onChange={(e) => setShopName(e.target.value)}
            className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="text-xs font-semibold text-gray-600 flex items-center gap-1 mb-1">
            <MapPin size={12} /> Address
          </label>
          <textarea
            value={shopAddress}
            onChange={(e) => setShopAddress(e.target.value)}
            rows={2}
            className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs font-semibold text-gray-600 flex items-center gap-1 mb-1">
              <Phone size={12} /> Phone
            </label>
            <input
              type="text"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="text-xs font-semibold text-gray-600 flex items-center gap-1 mb-1">
              <FileText size={12} /> GST Number
            </label>
            <input
              type="text"
              value={gst}
              onChange={(e) => setGst(e.target.value)}
              className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Optional"
            />
          </div>
        </div>

        {/* Inventory Settings */}
        <div className="border-t border-gray-100 pt-4">
          <div className="flex items-center gap-2 text-gray-700 mb-3">
            <AlertTriangle size={18} className="text-amber-500" />
            <h3 className="text-sm font-bold">Inventory Preferences</h3>
          </div>

          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
            <div>
              <p className="text-sm font-medium text-gray-700">Allow Negative Stock</p>
              <p className="text-[10px] text-gray-400">Let sales go through even when stock is zero</p>
            </div>
            <button
              type="button"
              onClick={() => setAllowNegativeStock(!allowNegativeStock)}
              className={`relative w-11 h-6 rounded-full transition-colors ${allowNegativeStock ? 'bg-blue-600' : 'bg-gray-300'}`}
            >
              <span className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform ${allowNegativeStock ? 'translate-x-5' : ''}`} />
            </button>
          </div>

          <div className="mt-3">
            <label className="text-xs font-semibold text-gray-600 mb-1 block">Default Low Stock Threshold</label>
            <input
              type="number"
              value={lowStockDefault}
              onChange={(e) => setLowStockDefault(e.target.value)}
              min="0"
              className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="w-full bg-blue-600 text-white py-3 rounded-xl font-semibold text-sm hover:bg-blue-700 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
        >
          <Save size={16} />
          {saving ? 'Saving...' : 'Save Settings'}
        </button>
      </form>

      {/* Backup & Restore */}
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
        <div className="flex items-center gap-2 text-gray-700 mb-2">
          <Cloud size={18} className="text-blue-600" />
          <h3 className="text-sm font-bold">Cloud Backup</h3>
        </div>
        <p className="text-xs text-gray-500 mb-3">
          Your app stays offline-first. Create a backup file and choose Google Drive from the Android share menu to keep a safe copy in the cloud.
        </p>
        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={handleBackup}
            className="bg-blue-600 text-white py-3 rounded-xl font-semibold text-sm hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
          >
            <Upload size={16} />
            Backup
          </button>
          <label className="bg-emerald-50 text-emerald-700 border border-emerald-200 py-3 rounded-xl font-semibold text-sm hover:bg-emerald-100 transition-colors flex items-center justify-center gap-2 cursor-pointer">
            <Download size={16} />
            Restore
            <input
              type="file"
              accept=".json,application/json"
              onChange={handleRestore}
              className="hidden"
            />
          </label>
        </div>
        <p className="text-[10px] text-gray-400 mt-2">
          To restore on another phone, choose the backup JSON from Google Drive when prompted.
        </p>
      </div>

      {/* Data Management */}
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
        <div className="flex items-center gap-2 text-gray-700 mb-3">
          <Database size={18} className="text-slate-600" />
          <h3 className="text-sm font-bold">Data Management</h3>
        </div>
        <p className="text-xs text-gray-500 mb-3">
          Your data is stored securely in the cloud and syncs automatically. Use the button below to permanently clear all records.
        </p>
        <button
          type="button"
          onClick={handleClearData}
          className="w-full bg-rose-50 text-rose-600 border border-rose-200 py-3 rounded-xl font-semibold text-sm hover:bg-rose-100 transition-colors flex items-center justify-center gap-2"
        >
          <Trash2 size={16} />
          Clear All Data
        </button>
      </div>

      {/* About */}
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
        <div className="flex items-center gap-2 text-gray-700 mb-2">
          <ShieldCheck size={18} className="text-emerald-500" />
          <h3 className="text-sm font-bold">About</h3>
        </div>
        <p className="text-xs text-gray-500">
          Toy & Cycle Inventory Manager v1.0. A complete shop management tool for tracking products, sales, purchases, expenses, and profitability.
        </p>
      </div>
    </div>
  );
}
