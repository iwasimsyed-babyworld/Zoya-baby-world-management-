ZOYA BABY WORLD — Android launcher icon pack

For an Android Studio project, copy the contents of this package's res/ folder into app/src/main/res/ and replace existing ic_launcher files if prompted.
Then rebuild/install the app. The icon is supplied in Android density sizes and with an adaptive-icon configuration for Android 8+.
